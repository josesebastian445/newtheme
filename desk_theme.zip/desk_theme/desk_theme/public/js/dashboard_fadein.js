// File: ~/frappe-bench/apps/my_custom_app/my_custom_app/public/js/dashboard_fadein.js
frappe.ready(() => {
    if (frappe.get_route_str() === "workspaces") { // Target the Workspaces/Dashboard route
        const widgets = document.querySelectorAll(".widget, .widget-group");
        widgets.forEach((widget, index) => {
            widget.style.animationDelay = `${index * 0.1}s`; // Stagger delay
            widget.style.opacity = 0; // Ensure hidden before animation
            // Add a class after a short delay to trigger the animation (or directly apply animation)
            setTimeout(() => {
                widget.classList.add("animated-on-load"); // Add a class to trigger animation
            }, 50); // Small initial delay
        });
    }
});

// In your CSS:
// .dashboard-widget.animated-on-load, .widget-group.animated-on-load {
//     animation: fadeInSlideUp 0.6s ease-out forwards;
// }